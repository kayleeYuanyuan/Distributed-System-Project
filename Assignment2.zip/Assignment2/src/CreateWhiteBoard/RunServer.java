package CreateWhiteBoard;

import java.io.IOException;
import java.net.BindException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RunServer {
	
	public static List<Connection> connections = new ArrayList<>();
	public static List<String> usernames = new ArrayList<>();
	public static void run(int port, String username) {
		ServerSocket serverSocket = null;
		usernames.add(username);
		try {
			serverSocket = new ServerSocket(port);
			Socket clientSocket = null;
			while (true) {
				clientSocket = serverSocket.accept();
				Connection connection = new Connection(clientSocket);
				connections.add(connection);
				connection.start();
			}
		} catch(BindException e) {
			System.out.println("Port is invalid! ");
			System.exit(0);
		} catch(SocketException e) {
			System.out.println("Scocket: " + e.getMessage());
			System.exit(0);
		} catch(IOException e) {
			System.out.println("IO: " + e.getMessage());
			System.exit(0);
		} catch(Exception e) {
			e.printStackTrace();
			System.exit(0);
		}
	}
}
