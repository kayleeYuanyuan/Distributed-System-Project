package CreateWhiteBoard;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Arrays;
import javax.swing.JOptionPane;

public class Connection extends Thread{
	public Socket socket;
	public String name;
	public DataInputStream dis;
	public DataOutputStream dos;
	public Connection(Socket socket) {
		this.socket = socket;
	}
	public void run() {
		try {
			dis = new DataInputStream(this.socket.getInputStream());
			dos = new DataOutputStream(this.socket.getOutputStream());
			String info;
			while ((info = dis.readUTF()) != null) {
				String[] output = info.split(" ", 2);
				if (output[0].equals("Begin")) {
					ArrayList<String> paintings = CreateWhiteBoard.createWhiteBoard.createDrawListener.getRecord();
					if (paintings.size() != 0) {
						try {
							String[] records = paintings.toArray(new String[paintings.size()]);
							for (String record : records) {
								for (int i = 0; i < RunServer.connections.size(); i++) {
									Connection con = RunServer.connections.get(i);
									con.dos.writeUTF("Draw " + record);
									con.dos.flush();
								}
							}
						} catch (IOException e1) {
							e1.printStackTrace();
						}
					}
					String str = "userList";
					for (String username : RunServer.usernames) {
						str += " " + username;
					}
					String[] users = str.split(" ");
					CreateWhiteBoard.createWhiteBoard.list.setListData(Arrays.copyOfRange(users, 1, users.length));
					for (int i = 0; i < RunServer.connections.size(); i++) {
						Connection con = RunServer.connections.get(i);
						con.dos.writeUTF(str);
						con.dos.flush();
					}
					continue;
				} else if (output[0].equals("Request")) {
					name = output[1];
					if (RunServer.usernames.contains(name)) {
						dos.writeUTF("Duplicate");
						dos.flush();
						RunServer.connections.remove(this);
					} else {
						int result = JOptionPane.showConfirmDialog(null, name + " wants to join your white board", "Select an Option", JOptionPane.INFORMATION_MESSAGE);
						if (result == JOptionPane.YES_OPTION) {
							RunServer.usernames.add(name);
							dos.writeUTF("Successful");
							dos.flush();
						} else if (result == JOptionPane.CANCEL_OPTION || result == JOptionPane.CLOSED_OPTION || result == JOptionPane.NO_OPTION) {
							dos.writeUTF("Fail");
							dos.flush();
							RunServer.connections.remove(this);
						}
					}
					continue;
				} else if (output[0].equals("Draw")) {
					for (int i = 0; i < RunServer.connections.size(); i++) {
						Connection con = RunServer.connections.get(i);
						con.dos.writeUTF("Draw " + output[1]);
						con.dos.flush();
					}
					Manager.createDrawListener.update(output[1]);
					Manager.canvas.repaint();
					continue;
				} else if (output[0].equals("End")) {
					socket.close();
					continue;
				} else if (output[0].equals("Chat")) {
					for (int i = 0; i < RunServer.connections.size(); i++) {
						Connection con = RunServer.connections.get(i);
						con.dos.writeUTF("Chat " + output[1]);
						con.dos.flush();
					}
					Manager.textArea.append(output[1] + "\n");
				} else if (output[0].equals("newuserList")) {
					String str = "userList";
					for (String username : RunServer.usernames) {
						str += " " + username;
					}
					String[] users = str.split(" ");
					CreateWhiteBoard.createWhiteBoard.list.setListData(Arrays.copyOfRange(users, 1, users.length));
					for (int i = 0; i < RunServer.connections.size(); i++) {
						Connection con = RunServer.connections.get(i);
						con.dos.writeUTF(str);
						con.dos.flush();
					}
					continue;
				} else if (output[0].equals("Leave")) {
					for (int i = 0; i < RunServer.connections.size(); i++) {
						Connection con = RunServer.connections.get(i);
						if (output[1].equals(con.name)) {
							RunServer.connections.remove(i);
							RunServer.usernames.remove(output[1]);
						}
					}
					String str = "userList";
					for (String username : RunServer.usernames) {
						str += " " + username;
					}
					String[] users = str.split(" ");
					CreateWhiteBoard.createWhiteBoard.list.setListData(Arrays.copyOfRange(users, 1, users.length));
					for (int i = 0; i < RunServer.connections.size(); i++) {
						Connection con = RunServer.connections.get(i);
						con.dos.writeUTF(str);
						con.dos.flush();
					}
					continue;
				}
			}
		} catch (SocketException e) {
			System.out.println("User " + name + "'s connection fails.");
		} catch (Exception e) {
			System.out.println("User " + name + "'s connection fails.");
		}
	}
}
