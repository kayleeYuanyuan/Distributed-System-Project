package CreateWhiteBoard;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Color;
import javax.swing.JScrollPane;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.Canvas;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Manager {

	public JFrame frame;
	public static JTextField textField;
	public static JTextArea textArea;
	public static CanvasPainter canvas;
	public static Listener createDrawListener;
	int width;
	int height;
	public static JList list;
	public static Manager createWhiteBoard;
	public static int curX,curY;
	public static String managerName;

	/**
	 * Create the application.
	 */
	public Manager(String managerName) {
		this.managerName = managerName;
		initialize(managerName);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(String managerName) {
		frame = new JFrame();
		frame.setTitle(managerName);
		frame.getContentPane().setFont(new Font("SimSun", Font.PLAIN, 12));
		frame.setBounds(0, 0, 1600, 800);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		createDrawListener = new Listener(frame);	
		
		JButton btnNewButton = new JButton("Line");
		btnNewButton.addActionListener(createDrawListener);
		btnNewButton.setFont(new Font("SimSun", Font.BOLD, 20));
		btnNewButton.setBounds(112, 10, 156, 44);
		btnNewButton.setActionCommand("Line");
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Circle");
		btnNewButton_1.addActionListener(createDrawListener);
		btnNewButton_1.setFont(new Font("SimSun", Font.BOLD, 20));
		btnNewButton_1.setBounds(292, 10, 156, 44);
		btnNewButton_1.setActionCommand("Circle");
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Oval");
		btnNewButton_2.addActionListener(createDrawListener);
		btnNewButton_2.setFont(new Font("SimSun", Font.BOLD, 20));
		btnNewButton_2.setBounds(472, 10, 156, 44);
		btnNewButton_2.setActionCommand("Oval");
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Rectangle");
		btnNewButton_3.addActionListener(createDrawListener);
		btnNewButton_3.setFont(new Font("SimSun", Font.BOLD, 20));
		btnNewButton_3.setBounds(655, 10, 156, 44);
		btnNewButton_3.setActionCommand("Rectangle");
		frame.getContentPane().add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Text");
		btnNewButton_4.addActionListener(createDrawListener);
		btnNewButton_4.setFont(new Font("SimSun", Font.BOLD, 20));
		btnNewButton_4.setBounds(844, 10, 165, 46);
		btnNewButton_4.setActionCommand("Text");
		frame.getContentPane().add(btnNewButton_4);
		
		canvas = new CanvasPainter();
		canvas.setBackground(new Color(255, 255, 255));
		canvas.setBounds(182, 90, 892, 572);
		canvas.setList(createDrawListener.getRecord());
		frame.getContentPane().add(canvas);
				
		JButton btnNewButton_5 = new JButton("Color");
		btnNewButton_5.addActionListener(createDrawListener);
		btnNewButton_5.setFont(new Font("SimSun", Font.BOLD, 20));
		btnNewButton_5.setBounds(1039, 10, 165, 44);
		btnNewButton_5.setActionCommand("Color");
		frame.getContentPane().add(btnNewButton_5);
		
		//userList
		list = new JList();
		list.setFont(new Font("SimSun", Font.BOLD, 20));
		list.setBackground(new Color(255, 255, 255));
		list.setBounds(20, 303, 143, 309);
		frame.getContentPane().add(list);
		String[] nameList = {managerName};
		list.setListData(nameList);
		
		//kick out
		JButton btnNewButton_6 = new JButton("Kick out");
		btnNewButton_6.addActionListener(createDrawListener);
		btnNewButton_6.setFont(new Font("SimSun", Font.BOLD, 20));
		btnNewButton_6.setBounds(30, 633, 133, 44);
		btnNewButton_6.setActionCommand("Kick out");
		frame.getContentPane().add(btnNewButton_6);
		
		//chat box
		textArea = new JTextArea();
		textArea.setEditable(false);
		textArea.setBounds(1093, 90, 180, 485);
		frame.getContentPane().add(textArea);
		
		textField = new JTextField();
		textField.setBounds(1093, 594, 180, 44);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton_7 = new JButton("Send");
		btnNewButton_7.addActionListener(createDrawListener);
		btnNewButton_7.setBackground(new Color(128, 255, 255));
		btnNewButton_7.setFont(new Font("SimSun", Font.BOLD, 20));
		btnNewButton_7.setBounds(1126, 649, 124, 41);
		btnNewButton_7.setActionCommand("Send");
		frame.getContentPane().add(btnNewButton_7);
		
		JLabel lblNewLabel = new JLabel("Chat");
		lblNewLabel.setFont(new Font("SimSun", Font.BOLD, 20));
		lblNewLabel.setBounds(1105, 64, 67, 16);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("userList");
		lblNewLabel_1.setFont(new Font("SimSun", Font.BOLD, 20));
		lblNewLabel_1.setBounds(20, 277, 99, 15);
		frame.getContentPane().add(lblNewLabel_1);
		
		JButton btnNewButton_8 = new JButton("New");
		btnNewButton_8.addActionListener(createDrawListener);
		btnNewButton_8.setFont(new Font("SimSun", Font.BOLD, 20));
		btnNewButton_8.setBounds(10, 56, 124, 35);
		btnNewButton_8.setActionCommand("New");
		frame.getContentPane().add(btnNewButton_8);
		
		JButton btnNewButton_9 = new JButton("Open");
		btnNewButton_9.addActionListener(createDrawListener);
		btnNewButton_9.setFont(new Font("SimSun", Font.BOLD, 20));
		btnNewButton_9.setBounds(10, 101, 124, 33);
		btnNewButton_9.setActionCommand("Open");
		frame.getContentPane().add(btnNewButton_9);
		
		JButton btnNewButton_10 = new JButton("Save");
		btnNewButton_10.addActionListener(createDrawListener);
		btnNewButton_10.setFont(new Font("SimSun", Font.BOLD, 20));
		btnNewButton_10.setBounds(10, 144, 124, 33);
		btnNewButton_10.setActionCommand("Save");
		frame.getContentPane().add(btnNewButton_10);
		
		JButton btnNewButton_11 = new JButton("Save As");
		btnNewButton_11.addActionListener(createDrawListener);
		btnNewButton_11.setFont(new Font("SimSun", Font.BOLD, 20));
		btnNewButton_11.setBounds(10, 187, 124, 33);
		btnNewButton_11.setActionCommand("Save As");
		frame.getContentPane().add(btnNewButton_11);
		
		JButton btnNewButton_12 = new JButton("Close");
		btnNewButton_12.addActionListener(createDrawListener);
		btnNewButton_12.setFont(new Font("SimSun", Font.BOLD, 20));
		btnNewButton_12.setBounds(10, 230, 124, 37);
		btnNewButton_12.setActionCommand("Close");
		frame.getContentPane().add(btnNewButton_12);	
		
		this.frame.setVisible(true);
        this.frame.setResizable(false);
		
		canvas.addMouseListener(createDrawListener);
		canvas.addMouseMotionListener(createDrawListener);
		createDrawListener.g = (Graphics2D) canvas.getGraphics();
		
	}
}
