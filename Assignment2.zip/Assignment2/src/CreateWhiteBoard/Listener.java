package CreateWhiteBoard;

import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.JColorChooser;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.WindowConstants;

import JoinWhiteBoard.JoinWhiteBoard;


public class Listener implements ActionListener, MouseListener, MouseMotionListener{
	Graphics2D g;
	JFrame frame;
	int startX,startY,endX,endY;
	Object type;
	static Color color = Color.BLACK;
	String rgb = "0 0 0";
	String record;
	ArrayList<String> recordList = new ArrayList<>();
	
	public Listener() {
		
	}
	public Listener(JFrame frame) {
		this.frame = frame;
		this.type = "Line";
	}
	@Override
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		startX = e.getX();
		startY = e.getY();
		if (!g.getColor().equals(color)) {
			g.setColor(color);
		}
	}
	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		endX = e.getX();
		endY = e.getY();
		rgb = color.getRed() + " " + color.getGreen() + " " + color.getBlue();
		if (type.equals("Line")) {
			g.drawLine(startX, startY, endX, endY);
			record = "Line" + " " + rgb + " " + startX + " " + startY + " " + endX + " " + endY + " #";
			recordList.add(record);
		} else if (type.equals("Circle")) {
			int radius = (int) Math.sqrt(Math.pow(endX - startX, 2) + Math.pow(endY - startY, 2));
			g.drawOval(startX - radius, startY - radius, 2*radius, 2*radius);
			record = "Circle" + " " + rgb + " " + startX + " " + startY + " " + endX + " " + endY + " #";
			recordList.add(record);
		} else if (type.equals("Oval")) {
			int width = Math.abs(endX - startX);
			int height = Math.abs(endY - startY);
			g.drawOval(startX - width, startY - height, 2*width, 2*height);
			record = "Oval" + " " + rgb + " " + startX + " " + startY + " " + endX + " " + endY + " #";
			recordList.add(record);
		} else if (type.equals("Rectangle")) {
			g.drawRect(Math.min(startX, endX), Math.min(startY, endY), Math.abs(startX - endX), Math.abs(startY - endY));
			record = "Rectangle" + " " + rgb + " " + startX + " " + startY + " " + endX + " " + endY + " #";
			recordList.add(record);
		} else if (type.equals("Text")) {
			String text = JOptionPane.showInputDialog("Enter your text");
			if (text != null) {
				Font f = new Font(null, Font.PLAIN, 15);
				g.setFont(f);
				g.drawString(text, endX, endY);
				record = "Text" + " " + rgb + " " + endX + " " + endY + " " + text + " #";
				recordList.add(record);
			}
		} else {
			return;
		}
		try {
			for (int i = 0; i < RunServer.connections.size(); i++) {
				Connection con = RunServer.connections.get(i);
				con.dos.writeUTF("Draw " + record);
				con.dos.flush();
			}
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getActionCommand().equals("Color")) {
			final JFrame jf = new JFrame("Color Penal");
			jf.setSize(350,450);
			jf.setLocationRelativeTo(null);
			jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
			Color newColor = JColorChooser.showDialog(jf, "Choose your color", null);
			if (newColor != null) {
				color = newColor;
			}
		} else if (e.getActionCommand().equals("New")) {
			Manager.canvas.removeAll();
			Manager.canvas.updateUI();
			this.recordList.clear();
			try {
				for (int i = 0; i < RunServer.connections.size(); i++) {
					Connection con = RunServer.connections.get(i);
					con.dos.writeUTF("New");
					con.dos.flush();
				}
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		} else if (e.getActionCommand().equals("Open")) {
			JFileChooser fileChooser = new JFileChooser();
	        int result = fileChooser.showOpenDialog(null);
	        if (result == JFileChooser.APPROVE_OPTION) {
	            File selectedFile = fileChooser.getSelectedFile();
	            Manager.canvas.removeAll();
				Manager.canvas.updateUI();
				this.recordList.clear();
				try {
					for (int i = 0; i < RunServer.connections.size(); i++) {
						Connection con = RunServer.connections.get(i);
						con.dos.writeUTF("New");
						con.dos.flush();
					}
				} catch (IOException e1) {
					e1.printStackTrace();
				}
	            try (BufferedReader reader = new BufferedReader(new FileReader(selectedFile))) {
	                String line;
	                while ((line = reader.readLine()) != null) {
	                    this.recordList.add(line);
	                }
	            } catch (IOException e1) {
	                e1.printStackTrace();
	            }
	            try {
	            	String[] records = this.recordList.toArray(new String[this.recordList.size()]);
	        		for (String record : records) {
	        			for (int i = 0; i < RunServer.connections.size(); i++) {
	        				Connection con = RunServer.connections.get(i);
	        				con.dos.writeUTF("Draw " + record);
	        				con.dos.flush();
	        			}
	        		}
				} catch (IOException e1) {
					e1.printStackTrace();
				}
	        }   
		} else if (e.getActionCommand().equals("Save")) {
			try {
	            BufferedWriter writer = new BufferedWriter(new FileWriter("file.txt"));
	            for (String record : this.recordList) {
	            	writer.write(record);
	                writer.newLine();
	            }
	            writer.close();
	            JOptionPane.showMessageDialog(null, "Save successfully !");
	        } catch (IOException e1) {
	            e1.printStackTrace();
	        }
		} else if (e.getActionCommand().equals("Save As")) {
	        JFileChooser fileChooser = new JFileChooser();
	        int result = fileChooser.showSaveDialog(null);
	        if (result == JFileChooser.APPROVE_OPTION) {
	            File selectedFile = fileChooser.getSelectedFile();
	            String filePath = selectedFile.getAbsolutePath();
	            if (!filePath.endsWith(".txt")) {
	                filePath += ".txt";
	            }
	            try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
	            	for (String record : this.recordList) {
		            	writer.write(record);
		                writer.newLine();
		            }
		            writer.close();
		            JOptionPane.showMessageDialog(null, "Save successfully !");
	            } catch (IOException e1) {
	                e1.printStackTrace();
	            }
	        }
		} else if (e.getActionCommand().equals("Close")) {
			System.exit(0);
		} else if (e.getActionCommand().equals("Send")) {
			String message = Manager.managerName + ": " + Manager.textField.getText();
			Manager.textArea.append(message + "\n");
			try {
				for (int i = 0; i < RunServer.connections.size(); i++) {
					Connection con = RunServer.connections.get(i);
					con.dos.writeUTF("Chat " + message);
					con.dos.flush();
				}
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			Manager.textField.setText("");
		} else if (e.getActionCommand().equals("Kick out")) {
			String user = Manager.list.getSelectedValue().toString();
			if (user.equals(Manager.managerName)) {
				JOptionPane.showMessageDialog(null, "You can not kick out yourself !");
				return;
			} else {
				for (int i = 0; i < RunServer.connections.size(); i++) {
					Connection con = RunServer.connections.get(i);
					if (user.equals(con.name)) {
						try {
							con.socket.close();
						} catch (IOException e1) {
							e1.printStackTrace();
						}
						RunServer.connections.remove(i);
						RunServer.usernames.remove(user);
						JOptionPane.showMessageDialog(null, user + " has been kick out!");
						String users = "";
						for (String username : RunServer.usernames) {
							users += username + " ";
						}
						String[] Users = users.split(" ");
						CreateWhiteBoard.createWhiteBoard.list.setListData(Users);
						for (int j = 0; j < RunServer.connections.size(); j++) {
							Connection con1 = RunServer.connections.get(j);
							try {
								con1.dos.writeUTF("userList " + users);
								con1.dos.flush();
							} catch (IOException e1) {
								e1.printStackTrace();
							}
						}
						break;
					}
				}
			}
		} else {
			this.type = e.getActionCommand();
		}
		
	}
	public ArrayList<String> getRecord() {
		return recordList;
	}
	public void update(String line) {
		recordList.add(line);
	}
}
