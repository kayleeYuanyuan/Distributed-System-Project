package CreateWhiteBoard;

public class CreateWhiteBoard {
	public static String IPAddress;
	public static int port;
	public static String userName;
	public static Manager createWhiteBoard;
	public static void main(String[] args) {
		try {
			if (args.length != 3) {
				System.out.println("Input is invalid! ");
				return;
			}
			IPAddress = args[0];
			port = Integer.parseInt(args[1]);
			userName = args[2];
			if (port < 1024 || port > 65535) {
				System.out.println("Port number is wrong! ");
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} 
		try {
			initialize();
		} catch (Exception e) {
			e.printStackTrace();
		} 
		RunServer.run(port, userName);
    }
	public static void initialize() {
		Listener createDrawListener = new Listener();
		createWhiteBoard = new Manager(userName);
	}
}
