package JoinWhiteBoard;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JColorChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.WindowConstants;

import CreateWhiteBoard.Connection;
//import CreateWhiteBoard.ConnectionManager;
import CreateWhiteBoard.Manager;
import CreateWhiteBoard.RunServer;

public class Listener1 implements ActionListener, MouseListener, MouseMotionListener{
	Graphics2D g2d;
	JFrame frame;
	int startX,startY,endX,endY;
	Object type;
	static Color color = Color.BLACK;
	String rgb = "0 0 0";
	String record;
	ArrayList<String> recordList = new ArrayList<>();
	
	public Listener1() {
		
	}
	public Listener1(JFrame frame) {
		this.frame = frame;
		this.type = "Line";
	}
	@Override
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		startX = e.getX();
		startY = e.getY();
		if (!g2d.getColor().equals(color)) {
			g2d.setColor(color);
		}
	}
	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		endX = e.getX();
		endY = e.getY();
		rgb = color.getRed() + " " + color.getGreen() + " " + color.getBlue();
		if (type.equals("Line")) {
			g2d.drawLine(startX, startY, endX, endY);
			record = "Line" + " " + rgb + " " + startX + " " + startY + " " + endX + " " + endY + " #";
			recordList.add(record);
		} else if (type.equals("Circle")) {
			int radius = (int) Math.sqrt(Math.pow(endX - startX, 2) + Math.pow(endY - startY, 2));
			g2d.drawOval(startX - radius, startY - radius, 2*radius, 2*radius);
			record = "Circle" + " " + rgb + " " + startX + " " + startY + " " + endX + " " + endY + " #";
			recordList.add(record);
		} else if (type.equals("Oval")) {
			int width = Math.abs(endX - startX);
			int height = Math.abs(endY - startY);
			g2d.drawOval(startX - width, startY - height, 2*width, 2*height);
			record = "Oval" + " " + rgb + " " + startX + " " + startY + " " + endX + " " + endY + " #";
			recordList.add(record);
		} else if (type.equals("Rectangle")) {
			g2d.drawRect(Math.min(startX, endX), Math.min(startY, endY), Math.abs(startX - endX), Math.abs(startY - endY));
			record = "Rectangle" + " " + rgb + " " + startX + " " + startY + " " + endX + " " + endY + " #";
			recordList.add(record);
		} else if (type.equals("Text")) {
			String text = JOptionPane.showInputDialog("Enter your text");
			if (text != null) {
				Font f = new Font(null, Font.PLAIN, 15);
				g2d.setFont(f);
				g2d.drawString(text, endX, endY);
				record = "Text" + " " + rgb + " " + endX + " " + endY + " " + text + " #";
				recordList.add(record);
			}
		} else {
			return;
		}
		try {
			JoinWhiteBoard.connection.dos.writeUTF("Draw " + record);
			JoinWhiteBoard.connection.dos.flush();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getActionCommand().equals("Color")) {
			final JFrame jf = new JFrame("Color Penal");
			jf.setSize(350,450);
			jf.setLocationRelativeTo(null);
			jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
			Color newColor = JColorChooser.showDialog(jf, "Choose your color", null);
			if (newColor != null) {
				color = newColor;
			}
		} else if (e.getActionCommand().equals("Send")) {
			String message = Guest.userName + ": " + Guest.textField.getText();
			try {
				JoinWhiteBoard.connection.dos.writeUTF("Chat " + message);
				JoinWhiteBoard.connection.dos.flush();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			Guest.textField.setText("");
		} else {
			this.type = e.getActionCommand();
		}
		
	}
	public ArrayList<String> getRecord() {
		return recordList;
	}
	public void update(String line) {
		recordList.add(line);
	}
}
