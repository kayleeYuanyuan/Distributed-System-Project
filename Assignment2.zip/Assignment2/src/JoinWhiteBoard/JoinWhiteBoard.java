package JoinWhiteBoard;

import java.io.IOException;
import java.net.BindException;
import java.net.Socket;
import java.net.SocketException;
import java.util.concurrent.TimeUnit;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import CreateWhiteBoard.Listener;
import CreateWhiteBoard.Manager;
import CreateWhiteBoard.RunServer;

public class JoinWhiteBoard {
	public static String IPAddress;
	public static int port;
	public static String userName;
	public static Connection connection;
	public static Socket client = null;
	public static Guest guest;
	public static JFrame frame;
	public static JTextField textField;
	
	public static void main(String[] args) {
		try {
			if (args.length != 3) {
				System.out.println("Input is invalid! ");
				return;
			}
			IPAddress = args[0];
			port = Integer.parseInt(args[1]);
			userName = args[2];
			if (port < 1024 || port > 65535) {
				System.out.println("Port number is wrong! ");
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} 
		try {
			client = new Socket(IPAddress, port);
			connection = new Connection(client);
			connection.dos.writeUTF("Request " + userName);
			connection.dos.flush();
			connection.join();
			initialize();
			connection.run();
		} catch(BindException e) {
			System.out.println("Port is invalid! ");
			System.exit(0);
		} catch(SocketException e) {
			System.out.println("Scocket: " + e.getMessage());
			System.exit(0);
		} catch (IOException e) {
			System.out.println("IO: " + e.getMessage());
			System.exit(0);
		} catch(Exception e) {
			e.printStackTrace();
			System.exit(0);
		}
    }
	public static void initialize() {
		Listener1 createDrawListener = new Listener1();
		try {
			String status = connection.getCurrentStatus();
			if (status.equals("duplicate")) {
				JOptionPane.showMessageDialog(frame, "Username exists!");
				connection.resetStatus();
				client.close();
				System.exit(1);
			} else if (status.equals("successful")) {
				try {
					guest = new Guest(connection, userName);
					connection.dos.writeUTF("Begin");
					connection.dos.flush();
				} catch (Exception e) {
					e.printStackTrace();
				}
								
			} else if (status.equals("fail")) {
				JOptionPane.showMessageDialog(frame, "Connection fails");
				try {
					connection.dos.writeUTF("End");
					connection.dos.flush();
					client.close();
					System.exit(1);
				} catch (Exception e) {
					e.printStackTrace();
				}
			} 
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
