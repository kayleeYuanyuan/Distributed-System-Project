package JoinWhiteBoard;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

import javax.swing.JOptionPane;


import CreateWhiteBoard.RunServer;

public class Connection {
	public Socket socket;
	public DataInputStream dis = null;
	public DataOutputStream dos = null;
	public String status;
	
	public Connection(Socket socket) {
		this.status = status;
		resetStatus();
		try {
			this.socket = socket;
			dos = new DataOutputStream(this.socket.getOutputStream());
			dis = new DataInputStream(this.socket.getInputStream());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void join() {
		try {
			String request = dis.readUTF();
			String[] commands = request.split(" ", 2);
			String command = commands[0];
			if (command.equals("Duplicate")) {
				this.status = "duplicate";
			} else if (command.equals("Successful")) {
				this.status = "successful";
			} else if (command.equals("Fail")) {
				this.status = "fail";
			} 
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public void run() {
		try {
			while (true) {
				String request = dis.readUTF();
				String[] commands = request.split(" ", 2);
				String command = commands[0];
				if (command.equals("Draw")) {
					Guest.listener.update(commands[1]);
					Guest.canvas.repaint();
				} else if (command.equals("New")) {
					Guest.canvas.removeAll();
					Guest.canvas.updateUI();
					Guest.listener.recordList.clear();
				} else if (command.equals("Chat")) {
					Guest.textArea.append(commands[1] + "\n");
				} else if (command.equals("userList")) {
					JoinWhiteBoard.guest.list.setListData(commands[1].split(" "));
				}
			}
		} catch (IOException e) {
			try {
				JOptionPane.showMessageDialog(null, "Disconnection with server.");
				System.exit(0);
			} catch (Exception e1) {
				System.exit(0);
			}
		}
	}

	public String getCurrentStatus() {
		return this.status;
	}
	public void resetStatus() {
		this.status = "wait";
		return;
	}

}
