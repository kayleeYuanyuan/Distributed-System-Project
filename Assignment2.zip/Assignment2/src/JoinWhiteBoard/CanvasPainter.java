package JoinWhiteBoard;

import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.ArrayList;

public class CanvasPainter extends JPanel{
	public ArrayList<String> recordList = new ArrayList<>();
	public void setList(ArrayList<String> recordList) {
		this.recordList = recordList;
	}
	public void paint(Graphics gr) {
		super.paint(gr);
		draw((Graphics2D) gr, this.recordList);
	}
	public void draw(Graphics2D g, ArrayList<String> recordList) {
		try {
			String[] recordArray = recordList.toArray(new String[recordList.size()]);
			for (String line: recordArray) {
				String[] record = line.split(" ");
				int red, green, blue;
				int startX = 0;
				int startY = 0;
				int endX = 0;
				int endY = 0;
				Color color;
				if (record[1].equals("#")) {
					continue;
				}
				red = Integer.parseInt(record[1]);
				green = Integer.parseInt(record[2]);
				blue = Integer.parseInt(record[3]);
				color = new Color(red, green, blue);
				g.setColor(color);
				if (!record[0].equals("Text")) {
					startX = Integer.parseInt(record[4]);
					startY = Integer.parseInt(record[5]);
					endX = Integer.parseInt(record[6]);
					endY = Integer.parseInt(record[7]);
				}
				if (record[0].equals("Line")) {
					g.drawLine(startX, startY, endX, endY);
				} else if (record[0].equals("Circle")) {
					int radius = (int) Math.sqrt(Math.pow(endX - startX, 2) + Math.pow(endY - startY, 2));
					g.drawOval(startX - radius, startY - radius, 2*radius, 2*radius);
				} else if (record[0].equals("Oval")) {
					int width = Math.abs(endX - startX);
					int height = Math.abs(endY - startY);
					g.drawOval(startX - width, startY - height, 2*width, 2*height);
				} else if (record[0].equals("Rectangle")) {
					g.drawRect(Math.min(startX, endX), Math.min(startY, endY), Math.abs(startX - endX), Math.abs(startY - endY));
				} else if (record[0].equals("Text")) {
					Font f = new Font(null, Font.PLAIN, 15);
					g.setFont(f);
					endX = Integer.parseInt(record[4]);
					endY = Integer.parseInt(record[5]);
					String text = record[6];
					g.drawString(text, endX, endY);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
