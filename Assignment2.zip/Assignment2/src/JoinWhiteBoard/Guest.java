package JoinWhiteBoard;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import CreateWhiteBoard.Manager;

public class Guest {

	public JFrame frame;
	public JList list;
	public static JTextField textField;
	public static JTextArea textArea;
	public static Listener1 listener;
	public static CanvasPainter canvas;
	public static Connection connection;
	public static String userName;

	/**
	 * Create the application.
	 * @param userName 
	 * @param connection 
	 */
	public Guest(Connection connection, String userName) {
		this.connection = connection;
		this.userName = userName;
		initialize(userName);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(String userName) {
		frame = new JFrame();
		frame.setTitle(userName);
		frame.getContentPane().setFont(new Font("SimSun", Font.PLAIN, 12));
		frame.setBounds(100, 100, 1600, 800);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		listener = new Listener1(frame);

		
		JButton btnNewButton = new JButton("Line");
		btnNewButton.addActionListener(listener);
		btnNewButton.setFont(new Font("SimSun", Font.BOLD, 20));
		btnNewButton.setBounds(112, 10, 156, 44);
		btnNewButton.setActionCommand("Line");
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Circle");
		btnNewButton_1.addActionListener(listener);
		btnNewButton_1.setFont(new Font("SimSun", Font.BOLD, 20));
		btnNewButton_1.setBounds(292, 10, 156, 44);
		btnNewButton_1.setActionCommand("Circle");
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Oval");
		btnNewButton_2.addActionListener(listener);
		btnNewButton_2.setFont(new Font("SimSun", Font.BOLD, 20));
		btnNewButton_2.setBounds(472, 10, 156, 44);
		btnNewButton_2.setActionCommand("Oval");
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Rectangle");
		btnNewButton_3.addActionListener(listener);
		btnNewButton_3.setFont(new Font("SimSun", Font.BOLD, 20));
		btnNewButton_3.setBounds(655, 10, 156, 44);
		btnNewButton_3.setActionCommand("Rectangle");
		frame.getContentPane().add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Text");
		btnNewButton_4.addActionListener(listener);
		btnNewButton_4.setFont(new Font("SimSun", Font.BOLD, 20));
		btnNewButton_4.setBounds(844, 10, 165, 46);
		btnNewButton_4.setActionCommand("Text");
		frame.getContentPane().add(btnNewButton_4);
		
		canvas = new CanvasPainter();
		canvas.setBackground(new Color(255, 255, 255));
		canvas.setBounds(182, 90, 892, 572);
		canvas.setList(listener.getRecord());
		frame.getContentPane().add(canvas);

		JButton btnNewButton_5 = new JButton("Color");
		btnNewButton_5.addActionListener(listener);
		btnNewButton_5.setFont(new Font("SimSun", Font.BOLD, 20));
		btnNewButton_5.setBounds(1039, 10, 165, 44);
		btnNewButton_5.setActionCommand("Color");
		frame.getContentPane().add(btnNewButton_5);
		
		//userList
		list = new JList();
		list.setFont(new Font("SimSun", Font.BOLD, 20));
		list.setBackground(new Color(255, 255, 255));
		list.setBounds(20, 303, 143, 309);
		frame.getContentPane().add(list);

		
		//chat box
		textArea = new JTextArea();
		textArea.setEditable(false);
		textArea.setBounds(1093, 90, 180, 485);
		frame.getContentPane().add(textArea);
		
		textField = new JTextField();
		textField.setBounds(1093, 594, 180, 44);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton_7 = new JButton("Send");
		btnNewButton_7.addActionListener(listener);
		btnNewButton_7.setBackground(new Color(128, 255, 255));
		btnNewButton_7.setFont(new Font("SimSun", Font.BOLD, 20));
		btnNewButton_7.setBounds(1126, 649, 124, 41);
		btnNewButton_7.setActionCommand("Send");
		frame.getContentPane().add(btnNewButton_7);
		
		JLabel lblNewLabel = new JLabel("Chat");
		lblNewLabel.setFont(new Font("SimSun", Font.BOLD, 20));
		lblNewLabel.setBounds(1105, 64, 67, 16);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("userList");
		lblNewLabel_1.setFont(new Font("SimSun", Font.BOLD, 20));
		lblNewLabel_1.setBounds(20, 277, 99, 15);
		frame.getContentPane().add(lblNewLabel_1);
		
		this.frame.setVisible(true);
        this.frame.setResizable(false);
		
		canvas.addMouseListener(listener);
		canvas.addMouseMotionListener(listener);
		listener.g2d = (Graphics2D) canvas.getGraphics();
		
		this.frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
            	try {
					JoinWhiteBoard.connection.dos.writeUTF("Leave " + userName);
					JoinWhiteBoard.connection.dos.flush();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
            }
        });
				
	}

}
