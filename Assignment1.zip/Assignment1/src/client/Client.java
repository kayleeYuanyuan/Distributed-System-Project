package client;

import java.net.*;
import java.util.concurrent.LinkedBlockingQueue;
import java.io.*;
import server.Server;

public class Client extends Thread {
	
	static int port;
	static String address;
	public BufferedReader in;
    public BufferedWriter out;
    Socket client = null;
    public LinkedBlockingQueue<String> requestQueue = new LinkedBlockingQueue<>(1);
	
	public void run() {
		try {
			while (!isInterrupted()) {
				client = new Socket(address, port);
				in = new BufferedReader(new InputStreamReader(client.getInputStream(), "UTF-8"));
				out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream(), "UTF-8"));
				System.out.println("Connected successfully!");
				String message = null;
				while((message = requestQueue.take()) != null) {
					out.write(message + "\n");
		            out.flush();
				}
			}
		} catch (UnknownHostException e) {
			e.printStackTrace();
			return;
		} catch (IOException e) {
			System.out.println("IO: " + e.getMessage());
			return;
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			if (client != null) {
				try {
					client.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	//receive response from connection
    public String getResponse() {
    	String respone = null;
        try {
            respone = in.readLine();
        } catch (IOException e) {
        	e.printStackTrace();
        } catch (Exception e) {
        	e.printStackTrace();
        }
        return respone;
    }
}
