package client;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTextArea;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.awt.event.ActionEvent;

public class clientGUI {

	public JFrame frame;
	private JTextField textField_word;
	private JTextField textField_meaning;
	Client client = new Client();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		try {
			if(args.length != 2) {
				System.out.println("Input is invalid! ");
				return;
			}
			Client.address = args[0];
			Client.port = Integer.parseInt(args[1]);
			if (Client.port < 1024 || Client.port > 65535) {
				System.out.println("Port number is wrong! ");
				return;
			}
			System.out.println("Connection established");
		} catch (Exception e) {
			e.printStackTrace();
		} 
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					clientGUI window = new clientGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				} 
			}
		});
	}

	/**
	 * Create the application.
	 */
	public clientGUI() {
		client.start();
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("SimSun", Font.BOLD, 12));
		frame.setBounds(350, 150, 600, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Dictionary");
		lblNewLabel.setFont(new Font("SimSun", Font.BOLD, 25));
		lblNewLabel.setBounds(208, 10, 176, 36);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Word");
		lblNewLabel_1.setFont(new Font("SimSun", Font.BOLD, 20));
		lblNewLabel_1.setBounds(39, 69, 106, 82);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Meaning");
		lblNewLabel_2.setFont(new Font("SimSun", Font.BOLD, 20));
		lblNewLabel_2.setBounds(39, 193, 106, 36);
		frame.getContentPane().add(lblNewLabel_2);
		
		textField_word = new JTextField();
		textField_word.setBounds(129, 92, 304, 44);
		frame.getContentPane().add(textField_word);
		textField_word.setColumns(10);
		
		textField_meaning = new JTextField();
		textField_meaning.setBounds(129, 188, 304, 44);
		frame.getContentPane().add(textField_meaning);
		textField_meaning.setColumns(10);
		
		JTextArea textArea = new JTextArea();
		textArea.setRows(4);
		textArea.setFont(new Font("Monospaced", Font.PLAIN, 15));
		textArea.setLineWrap(true);
		textArea.setEditable(false);
		textArea.setBounds(39, 265, 525, 64);
		frame.getContentPane().add(textArea);
		
		JButton btnNewButton = new JButton("Add");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String word = textField_word.getText();
				String meaning = textField_meaning.getText();
				if (word.length() == 0 || meaning.length() == 0) {
					textArea.setText("You must input a word and meaning!");
				} else {
					try {
						String command = "Add" + "#" + word + "#" + meaning;
						while (client.requestQueue.size() == 0) {
							client.requestQueue.put(command);
							System.out.println(command);
							break;
						}
						String response = client.getResponse();
						System.out.println(response);
						if (response == null) {
							textArea.setText("You are not connected.");
						} else if (response.equals("duplicate")) {
							textArea.setText("It has been added to the dictionary.");
						} else if (response.equals("successful")) {
							textArea.setText("Your word is added into the dictionary successfully.");
						} else {
							textArea.setText("Add failed.");
						}
					} catch(Exception e1) {
						e1.printStackTrace();
					}
				}
				textField_word.setText("");
				textField_meaning.setText("");
			}
		});
		btnNewButton.setBackground(new Color(128, 255, 255));
		btnNewButton.setFont(new Font("SimSun", Font.BOLD, 20));
		btnNewButton.setForeground(new Color(0, 0, 0));
		btnNewButton.setBounds(77, 347, 116, 42);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnRemove = new JButton("Remove");
		btnRemove.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String word = textField_word.getText();
				if (word.length() == 0) {
					textArea.setText("You must input a word!");
				} else {
					try {
						String command = "Remove" + "#" + word;
						while (client.requestQueue.size() == 0) {
							client.requestQueue.put(command);
							System.out.println(command);
							break;
						}
						String response = client.getResponse();
						System.out.println(response);
						if (response == null) {
							textArea.setText("You are not connected.");
						} else if (response.equals("fail")) {
							textArea.setText("Your word is not in the dictionary!");
						} else if (response.equals("successful")) {
							textArea.setText("Your word is removed from the dictionary successfully.");
						} else {
							textArea.setText("Failed.");
						}
					} catch(Exception e1) {
						e1.printStackTrace();
					}
				}
				textField_word.setText("");
			}
		});
		btnRemove.setForeground(Color.BLACK);
		btnRemove.setFont(new Font("SimSun", Font.BOLD, 20));
		btnRemove.setBackground(new Color(128, 255, 255));
		btnRemove.setBounds(368, 347, 116, 42);
		frame.getContentPane().add(btnRemove);
		
		JButton btnQuery = new JButton("Query");
		btnQuery.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String word = textField_word.getText();
				if (word.length() == 0) {
					textArea.setText("You must input a word!");
				} else {
					try {
						String command = "Query" + "#" + word;
						while(client.requestQueue.size() == 0) {
							client.requestQueue.put(command);
							System.out.println(command);
							break;
						}
						String response = client.getResponse();
						System.out.println(response);
						if (response == null) {
							textArea.setText("You are not connected.");
						} else if (response.equals("fail")) {
							textArea.setText("Your word is not in the dictionary!");
						} else if (response.equals("successful")) {
							String meaning = client.getResponse();
							textArea.setText(meaning);
						} else {
							textArea.setText("Failed.");
						}
					} catch(Exception e1) {
						e1.printStackTrace();
					}
				}
				textField_word.setText("");
			}
		});
		btnQuery.setForeground(Color.BLACK);
		btnQuery.setFont(new Font("SimSun", Font.BOLD, 20));
		btnQuery.setBackground(new Color(128, 255, 255));
		btnQuery.setBounds(77, 399, 116, 42);
		frame.getContentPane().add(btnQuery);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String word = textField_word.getText();
				String meaning = textField_meaning.getText();
				if (word.length() == 0 || meaning.length() == 0) {
					textArea.setText("You must input a word and meaning!");
				} else {
					try {
						String command = "Update" + "#" + word + "#" + meaning;
						while(client.requestQueue.size() == 0) {
							client.requestQueue.put(command);
							System.out.println(command);
							break;
						}
						String response = client.getResponse();
						System.out.println(response);
						if (response == null) {
							textArea.setText("You are not connected.");
						} else if (response.equals("fail")) {
							textArea.setText("Your word is not in the dictionary!");
						} else if (response.equals("successful")) {
							textArea.setText("Congratulations! The update is successful.");
						} else {
							textArea.setText("Failed.");
						}
					} catch(Exception e1) {
						e1.printStackTrace();
					}
				}
				textField_word.setText("");
				textField_meaning.setText("");
			}
		});
		btnUpdate.setForeground(Color.BLACK);
		btnUpdate.setFont(new Font("SimSun", Font.BOLD, 20));
		btnUpdate.setBackground(new Color(128, 255, 255));
		btnUpdate.setBounds(369, 399, 116, 42);
		frame.getContentPane().add(btnUpdate);
		
	}
}
