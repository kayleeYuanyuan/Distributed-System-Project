package server;

import java.net.*;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;
import java.io.*;
import java.util.Map;

public class Server extends Thread {
	
	private static Server server;
	static int port;
	public static Hashtable<String, List<String>> dictionary = new Hashtable<String, List<String>>();
	static String textFile = "src/dictionary.txt";
	ServerSocket serverSocket = null;
	
	public void run() {
		try {
			serverSocket = new ServerSocket(port);
			Socket clientSocket = null;
			while(true) {
				clientSocket = serverSocket.accept();
				Connection connection = new Connection(clientSocket);
				connection.start();
			}
		} catch(BindException e) {
			System.out.println("Port is invalid! ");
			return;
		} catch(SocketException e) {
			System.out.println("Scocket: " + e.getMessage());
			return;
		} catch(IOException e) {
			System.out.println("IO: " + e.getMessage());
			return;
		} catch(Exception e) {
			e.printStackTrace();
			return;
		} finally {
			if(serverSocket != null) {
				try {
					serverSocket.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	public void readTextFile() {
		File file = new File(textFile);
		if (file.isFile() && file.exists()) {
	        try (BufferedReader br = new BufferedReader(new FileReader(textFile))) {
	            String line;
	            while ((line = br.readLine()) != null) {
	            	String[] word = line.split(":");
	            	String words = word[1].substring(1, word[1].length()-1);
	            	String[] wordsArr = words.split(",");
	            	List<String> meanings = Arrays.asList(wordsArr); 
	                dictionary.put(word[0], meanings);
	            }
	        } catch (IOException e) {
	            e.printStackTrace();
	        } 
		}
		else {
			System.out.println("Your file is not exist!");
		}
    }
	public static void writeTextFile() {
		File file = new File(textFile);
		BufferedWriter writer = null;
		try {
			if (file.exists() == false) {
				file = new File(textFile);
			}
			writer = new BufferedWriter(new FileWriter(file));
			for (Map.Entry<String, List<String>> entry : dictionary.entrySet()) {
		        writer.write(entry.getKey() + ":" + entry.getValue() + System.lineSeparator());
		    }
		} catch (IOException e) {
            e.printStackTrace();
        } finally {
        	try {
        		writer.flush();
        		writer.close();
        	} catch (IOException e) {
        		e.printStackTrace();
        	}
        }
	}
}
