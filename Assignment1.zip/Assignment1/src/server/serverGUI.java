package server;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import java.awt.BorderLayout;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class serverGUI {

	private JFrame frame;
	private JTextField textField_port;
	private JTextField textField_file;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					serverGUI window = new serverGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public serverGUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(192, 192, 192));
		frame.setBounds(350, 150, 600, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Dictionary Server");
		lblNewLabel.setFont(new Font("SimSun", Font.BOLD, 25));
		lblNewLabel.setBounds(147, 10, 261, 36);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Port:");
		lblNewLabel_1.setFont(new Font("SimSun", Font.BOLD, 20));
		lblNewLabel_1.setBounds(41, 52, 106, 82);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Dictionary File:");
		lblNewLabel_2.setFont(new Font("SimSun", Font.BOLD, 20));
		lblNewLabel_2.setBounds(20, 186, 180, 36);
		frame.getContentPane().add(lblNewLabel_2);
		
		textField_port = new JTextField();
		textField_port.setBounds(127, 112, 304, 44);
		frame.getContentPane().add(textField_port);
		textField_port.setColumns(10);
		
		textField_file = new JTextField();
		textField_file.setBounds(127, 248, 304, 44);
		frame.getContentPane().add(textField_file);
		textField_file.setColumns(10);
		
		JTextArea textArea = new JTextArea();
		textArea.setRows(4);
		textArea.setFont(new Font("Monospaced", Font.PLAIN, 15));
		textArea.setLineWrap(true);
		textArea.setEditable(false);
		textArea.setBounds(41, 390, 525, 52);
		frame.getContentPane().add(textArea);
		
		JButton btnNewButton = new JButton("Start");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String port = textField_port.getText();
				String file = textField_file.getText();
				if(port.isEmpty() || file.isEmpty()) {
					textArea.setText("You must input a port and a file.");
					return;
				}
				Server.port = Integer.parseInt(port);
				Server.textFile = file;
				if (Server.port < 1024 || Server.port > 65535) {
					textArea.setText("Port number is wrong! ");
					return;
				}
				String str = String.format("Port is %d. \nDictionary file is %s.", Server.port, Server.textFile);
				textArea.setText(str);
				Server server = new Server();
				server.readTextFile();
				server.start();

			}
		});
		btnNewButton.setForeground(new Color(0, 0, 0));
		btnNewButton.setFont(new Font("SimSun", Font.BOLD, 20));
		btnNewButton.setBounds(181, 317, 180, 63);
		frame.getContentPane().add(btnNewButton);
		
	}
}
