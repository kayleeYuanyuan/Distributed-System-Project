package server;

import java.net.*;
import java.util.Arrays;
import java.util.List;
import java.io.*;

public class Connection extends Thread {
	
	public Socket socket = null;
	public BufferedReader in;
	public BufferedWriter out;
	
	public Connection(Socket socket) {
		this.socket = socket;
		try {
			in = new BufferedReader(new InputStreamReader(socket.getInputStream(), "UTF-8"));
			out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), "UTF-8"));
		} catch (IOException e) {
			e.printStackTrace();	
		}
	}
	
	public void run() {
		String respone = null;
		try {
			while ((respone = in.readLine()) != null) {
				System.out.println(respone);
				String[] dic = respone.split("#");
				if (dic[0].equals("Add")) {
					if (Server.dictionary.containsKey(dic[1])) {
						out.write("duplicate" + "\n");
			            out.flush();
					} else {
						out.write("successful" + "\n");
			            out.flush();
			            String[] meaningsArr = dic[2].split(",");
		            	List<String> meanings = Arrays.asList(meaningsArr); 
			            Server.dictionary.put(dic[1], meanings);
					}
				}
				else if (dic[0].equals("Query")) {
					if (Server.dictionary.containsKey(dic[1])) {
						out.write("successful" + "\n");
						out.flush();
						List<String> meanings = Server.dictionary.get(dic[1]);
						String meanStr = "";
						int num = 1;
						for (String meaning : meanings) {
							meanStr = meanStr + num + ". " + meaning + " ";
							num += 1;
                        }
						out.write(meanStr + "\n");
						out.flush();
					} else {
						out.write("fail" + "\n");
						out.flush();
					}
				}
				else if (dic[0].equals("Remove")) {
					if (Server.dictionary.containsKey(dic[1])) {
						Server.dictionary.remove(dic[1]);
						out.write("successful" + "\n");
			            out.flush();
					} else {
						out.write("fail" + "\n");
			            out.flush();
					}
				}
				else if (dic[0].equals("Update")) {
					if (Server.dictionary.containsKey(dic[1])) {
						String[] meaningsArr = dic[2].split(",");
		            	List<String> meanings = Arrays.asList(meaningsArr); 
			            Server.dictionary.put(dic[1], meanings);
						out.write("successful" + "\n");
			            out.flush();
					} else {
						out.write("fail" + "\n");
			            out.flush();
					}
				}
				Server.writeTextFile();
			}
		}catch (IOException e) {
			e.printStackTrace();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
}


